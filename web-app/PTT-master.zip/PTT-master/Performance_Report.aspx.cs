﻿//Samantha Ekanem

using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using static PTT.Performance_WebForm;



namespace PTT
{
    public partial class Performance_WebForm : System.Web.UI.Page
    {
        //stores database connection
        //private string connectionString = "Server=127.0.0.1;Database=web_app;User ID=root;Password=pass;";
        protected void Page_Load(object sender, EventArgs e)
        {

            // Check if the user is logged in
            if (Session["UTD_ID"] == null)
            {
                // User is not logged in, redirect to login page
                Response.Redirect("Login Page.aspx");
            }

            //Store utd_id 
            string utd_id = Session["UTD_ID"].ToString();

            if (!IsPostBack)
            {
                //Set correct page title
                Label pageTitle = (Label)this.Master.FindControl($"PageTitle");
                pageTitle.Text = "Performance Report";
            }

        }

    }

}
  
